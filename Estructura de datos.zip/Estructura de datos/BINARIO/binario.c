#include <stdio.h>
#include <stdlib.h>

int main() {
	
	FILE *A_binario=NULL;
	int a=0,b=5,i=0;
	
		//ESCRITURA DE ARCHIVO BINARIO
		
		A_binario=fopen("archivo_binario.bin","wb"); //abre el archivo
		
	    fwrite(&b,sizeof(int),1,A_binario); //escribe la cantidad de datos que se escribiran
	    
	for(i=0;i<b; i++){
		printf("Escribe un numero: ");
		scanf("%d",&a);
		fwrite(&a,sizeof(int),1,A_binario);
		  //dato que va a introducir,tama�o o tipo de dato, cuantas veces vamos a escribir, en donde 
		}
	fclose(A_binario);

		
		//LECTURA DE ARCHIVO BINARIO

	A_binario=fopen("archivo_binario.bin","rb");
	int datos=0;
	
	fread(&datos, sizeof(int),1,A_binario);
	
		for(i=0;i<datos; i++){
		fread(&a,sizeof(int),1,A_binario);
		printf("\nEl valor es: %d",a);
		//Pila=push(a,Pila);
		
		
		}
	fclose(A_binario);
	
		
	
	return 0;
}
