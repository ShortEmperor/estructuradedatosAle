#ifndef _Pila_H_
#define _Pila_H_
#include <stdio.h>
#include <stdlib.h>

typedef struct _Nodo{
	int dato;
	struct _Nodo*siguiente;
}Nodo;

Nodo*crearNodo(int d){ //Crea el nodo

	Nodo*nuevo;
	 nuevo=(Nodo*)malloc(sizeof(Nodo));
	 nuevo->dato=d;
 	 nuevo->siguiente=NULL;
		return nuevo;
	}

Nodo *push(int dato, Nodo *Pila){ //Iserta datos al nodo
	Nodo *nuevo;
	nuevo=crearNodo(dato);
	if(Pila!=NULL){
		nuevo->siguiente=Pila;
	}
	return nuevo;	
}

void verShow(Nodo *Pila){ //Muestra la pila
	if(Pila==NULL){
		printf("NULO");
	}else{
		while(Pila!=NULL){
			printf("\t %d", Pila->dato);
			Pila=Pila->siguiente;	
			}
		}
    } 	
    
    Nodo *pop(Nodo *Pila){ //Borra la pila
    	Nodo *borrar;
    	borrar=Pila;
    	if(Pila !=NULL){
    		Pila=Pila->siguiente;
    		free(borrar);
		}
		return Pila;
	}
		
		



#endif