#include "Pila.h"
int main()
{
	Nodo *Pila = NULL;
	Nodo *PilaCopia = NULL;
	Nodo *PilaIn = NULL;

	FILE *P_binario = NULL;
	int a = 0, b = 3, i = 0;

	// ESCRITURA DE ARCHIVO BINARIO
	P_binario = fopen("archivoB.bin", "wb"); // abre el archivo
	fwrite(&b, sizeof(int), 1, P_binario);	 // escribe la cantidad de datos que se escribiran
	for (i = 0; i < b; i++)
	{
		printf("Escribe el numero: ");		   // iniciamos ciclo para pedir datos
		scanf("%d", &a);					   // los guarda en a
		fwrite(&a, sizeof(int), 1, P_binario); // los escribe en el archivo
		// Pila=push(a,Pila);					//guarda en Pila
		// dato que va a introducir,tama�o o tipo de dato, cuantas veces vamos a escribir, en donde
	}
//	fclose(P_binario);

	// LEER ARCHIVO
	P_binario = fopen("archivoB.bin", "rb");
	int datos = 0;

	fread(&datos, sizeof(int), 1, P_binario);
	for (i = 0; i < datos; i++)
	{
		fread(&a, sizeof(int), 1, P_binario);
		// printf("\t %d ",a);
		Pila = push(a, Pila);
		PilaCopia = push(a, Pila);
	}
	printf("Pila:  ");
	verShow(Pila);
	printf("\n ");
	fclose(P_binario);

	// Invertir pila
	while(PilaCopia!=NULL){
		PilaIn = push(a, Pila);
		PilaCopia = pop(PilaCopia);
		PilaCopia=PilaCopia->siguiente;
	};
	printf("\n");
	verShow(PilaIn);

	if(Pila==PilaIn){
		printf("El numero SI es capicua");
	}else{
		printf("El numero NO es capicua");
	}
}
