#include <stdio.h>
#include <stdlib.h>
/*		Hacer un programa que lea un archivo binario, obtener los datos y guardarlos 
			en un nodo de tipo pila y leer la pila
*/
	FILE *B_binario=NULL;
	
	//leer archivo binario
		A_binario=fopen("archivo_binario.bin","rb");
	int datos=0;
	
	fread(&datos, sizeof(int),1,A_binario);
	
		for(i=0;i<datos; i++){
		fread(&a,sizeof(int),1,A_binario);
		printf("\nEl valor es: %d",a);
		
		}
	fclose(A_binario);

