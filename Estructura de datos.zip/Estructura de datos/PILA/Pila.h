#ifndef _Pila_H_
#define _Pila_H_
#include <stdio.h>
#include <stdlib.h>

typedef struct _Nodo{
	int dato;
	struct _Nodo*siguiente;
}Nodo;

Nodo*crearNodo(int d){

	Nodo*nuevo;
	 nuevo=(Nodo*)malloc(sizeof(Nodo));
	 nuevo->dato=d;
 	 nuevo->siguiente=NULL;
		return nuevo;
	}

Nodo *push(int dato, Nodo *Pila){
	Nodo *nuevo;
	nuevo=crearNodo(dato);
	if(Pila!=NULL)
		nuevo->siguiente=Pila;
		return nuevo;	
}

void verShow(Nodo *Pila){
	if(Pila==NULL){
		printf("NULO");
	}else{
		while(Pila!=NULL){
			printf("%d", Pila->dato);
			Pila=Pila->siguiente;	
			}
		}
    } 	
    
    Nodo *pop(Nodo *Pila){
    	Nodo *borrar;
    	borrar=Pila;
    	if(Pila !=NULL){
    		Pila=Pila->siguiente;
    		free(borrar);
		}
		return Pila;
	}
		
		



#endif

